﻿using CIMS_Entities;
using CIMS_Exceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIMS_DAL
{
    public class CarDAL
    {
        SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CARConnectionString"].ConnectionString);
        SqlDataReader objDr;
        public bool AddCarDAL(Car objCar)
        {
            bool CarAdded = false;         
            try
            {
                
                SqlCommand objCom = new SqlCommand("[46008527].AddCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", objCar.Model);
                SqlParameter objSqlParam_ManufacturerName = new SqlParameter("@manufacturername",objCar.ManufacturerName);
                SqlParameter objSqlParam_Type = new SqlParameter("@Cartype", objCar.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", objCar.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", objCar.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@Transmissiontype", objCar.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", objCar.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seats", objCar.Seats);
                SqlParameter objSqlParam_AirBagDetails = new SqlParameter("@AirBagDetails", objCar.AirBagDetails);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", objCar.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", objCar.Price);
                
                //
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_ManufacturerName);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_AirBagDetails);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);

                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                CarAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarAdded;
        }
        public bool UpdateCarDAL(Car objCar)
        {
            bool CarUpdated = false;
            try
            {
                SqlCommand objCom = new SqlCommand("[46008527].UpdateCar",objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", objCar.Model);
                SqlParameter objSqlParam_ManufacturerName = new SqlParameter("@manufacturername", objCar.ManufacturerName);
                SqlParameter objSqlParam_Type = new SqlParameter("@Cartype", objCar.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", objCar.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", objCar.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@Transmissiontype", objCar.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", objCar.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seats", objCar.Seats);
                SqlParameter objSqlParam_AirBagDetails = new SqlParameter("@AirBagDetails", objCar.AirBagDetails);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", objCar.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", objCar.Price);
                
                //
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_ManufacturerName);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_AirBagDetails);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);

                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                CarUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarUpdated;
        }

        public bool DeleteCarDAL(string model)
        {
            bool CarDeleted = false;         
            try
            {               
                SqlCommand objCom = new SqlCommand("[46008527].DeleteCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Model = new SqlParameter("@model",model);
                //
                objCom.Parameters.Add(objSqlParam_Model);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                CarDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarDeleted;
        }
        public Car SearchCarByModelDAL(string model)
        {
            Car objCar = null;
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008527].SearchCarByModel", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCom.Parameters.AddWithValue("@Model", model);
                //
                objDr = objCom.ExecuteReader();
                objDr.Read();
                if (objDr.HasRows)
                {
                    objCar = new Car();
                    //Binding Object with DataReader                 
                    objCar.Model = objDr[0].ToString()  ;
                    objCar.ManufacturerName=  objDr[1].ToString();
                    objCar.Type = objDr[2].ToString();
                    objCar.Engine = objDr[3].ToString();
                    objCar.BHP = Convert.ToInt32(objDr[4].ToString());
                    objCar.Transmission = objDr[5].ToString();
                    objCar.Mileage = Convert.ToInt32(objDr[6].ToString());
                    objCar.Seats = Convert.ToInt32(objDr[7].ToString());
                    objCar.AirBagDetails = objDr[8].ToString();
                    objCar.BootSpace = Convert.ToInt32(objDr[9].ToString());                   
                    objCar.Price = Convert.ToDouble(objDr[10].ToString());
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objCar;
        }
       
        public List<Car> ShowCarsDAL(string name,string type)
        {
            List<Car> objCars = new List<Car>();
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008527].ShowCars", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCom.Parameters.AddWithValue("@name", name);
                objCom.Parameters.AddWithValue("@type", type);
                //
                objDr = objCom.ExecuteReader();
                if (objDr.HasRows)
                {
                    while (objDr.Read())
                    {
                        Car car = new Car();
                        car.ManufacturerName = objDr[0].ToString();
                        car.Model = objDr[1].ToString();
                        car.Type = objDr[2].ToString();
                        car.Price = Convert.ToDouble(objDr[3].ToString());
                        objCars.Add(car);
                    }
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objCars;
        }
        public List<Car> ListCars()
        {
            List<Car> objCars = new List<Car>();
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008527].ListCars", objCon);
                objCom.CommandType = CommandType.StoredProcedure;               
                objDr = objCom.ExecuteReader();
                if (objDr.HasRows)
                {
                    while (objDr.Read())
                    {
                        Car car = new Car();
                        car.ManufacturerName = objDr[0].ToString();
                        car.Model = objDr[1].ToString();
                        car.Type = objDr[2].ToString();
                        car.Price = Convert.ToDouble(objDr[3].ToString());
                        objCars.Add(car);
                    }
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objCars;
        }

        public DataTable GetManufaturerNameDAL()
        {
            DataTable ManufaturerNameList = null;          
            try
            {              
                SqlCommand objCom = new SqlCommand("[46008527].GetManufacturerName", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                objDr = objCom.ExecuteReader();
                ManufaturerNameList = new DataTable();
                ManufaturerNameList.Load(objDr);
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return ManufaturerNameList;
        }

        public DataTable GetTypesDAL()
        {
            DataTable TypesList = null;          
            try
            {
                SqlCommand objCom = new SqlCommand("[46008527].GetTypes", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                objDr = objCom.ExecuteReader();
                TypesList = new DataTable();
                TypesList.Load(objDr);
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return TypesList;
        }

        public DataTable GetTransmissionDAL()
        {
            DataTable TransmissionList = null;
            try
            {               
                SqlCommand objCom = new SqlCommand("[46008527].GetTransmission", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                objDr = objCom.ExecuteReader();
                TransmissionList = new DataTable();
                TransmissionList.Load(objDr);
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return TransmissionList;
        }
        public bool LoginDAL(string userid, string password)
        {
            bool validate = false;
            try
            {
                SqlCommand objCom = new SqlCommand("[46008527].LoginDetails", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                objCom.Parameters.AddWithValue("@UserId", userid);
                objCom.Parameters.AddWithValue("@Password",password);
                objCon.Open();
                objDr = objCom.ExecuteReader();
                objDr.Read();
                if (objDr.HasRows)
                {
                    validate = true;
                }              
                return validate;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
        }
    }
}
