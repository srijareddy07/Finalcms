use Training_19Sep19_Pune
go

----------------AddCar----------------------------------

create procedure [46008527].AddCar
@Model varchar(50),
@ManufacturerId int,
@TypeId int,
@Engine varchar(10),
@BHP int,
@TransmissionId int,
@Mileage int,
@Seats int,
@AirBagDetails varchar(5),
@BootSpace varchar(10),
@Price decimal
as 
begin
insert into [46008527].Car Values(@Model,@ManufacturerId,@TypeId,@Engine,@BHP,@TransmissionId,@Mileage,@Seats,@AirBagDetails,@BootSpace,@Price)
end
go

----------------UpdateCar----------------------------------
create proc [46008527].UpdateCarDetails
(
@Model varchar(50),
@ManufacturerId int,
@TypeId int,
@Engine varchar(10),
@BHP int,
@TransmissionId int,
@Mileage int,
@Seats int,
@AirBagDetails varchar(5),
@BootSpace varchar(10),
@Price decimal
)
as
begin
update [8929].Car set Model=@Model, ManufacturerId=@ManufacturerId,TypeId=@TypeId,Engine=@Engine,BHP=@BHP,TransmissionId=@TransmissionId,Mileage=@Mileage,
Seats=@Seats,AirBagDetails=@AirBagDetails,BootSpace=@BootSpace,Price=@Price where Model=@model
end
go


-------------------SearchCarByModel-------------------

create procedure [46008527].SearchCarByModel
@model varchar(50)
as
begin
select Model,ManufacturerId,TypeId,Engine,BHP,TransmissionId,Mileage,Seats,AirBagDetails,BootSpace,Price from [46008527].Car C 
  where c.model=@Model
  end
go

----------------DeleteCar---------------------

create procedure [46008527].DeleteCar
@model varchar(20)
as
delete from [46008527].Car where Model=@model
go

-------------------ShowCars Based on Type And Maufacturer--------------------------

create procedure [46008527].ShowCars
@name varchar(50),
@type varchar(10)
as
begin
select ManufacturerId,Model,TypeId,Price from [46008527].Car C
 inner join [46008527].Manufacturer M on C.ManufacturerId=M.Id 
 inner join [46008527].CarType Ct1 on C.TypeId=Ct1.id
  inner join [46008527].CarTransmissionType CT on C.TransmissionId=CT.Id  
  where M.Name=@name and Ct1.Type=@type
  end
go

-----------------------Display All Cars-----------------------------

create procedure [46008527].ListCars
as
begin
select ManufacturerId,Model,TypeId,Price from [46008527].Car C
inner join [46008527].Manufacturer M on C.ManufacturerId=M.Id 
 inner join [46008527].CarType Ct1 on C.TypeId=Ct1.id
  inner join [46008527].CarTransmissionType CT on C.TransmissionId=CT.Id  
  end
go

----------------Login---------------------------
 create procedure [46008527].LoginDetails(
 @UserId varchar(20),
 @Password varchar(20))
 as
 begin
 select * from  [46008527].Login where UserId=@UserId and Password1=@Password
 end

 ------------------Get Manufacturers------------------

create procedure [46008527].GetManufacturerName
as
begin
select * from [46008527].Manufacturer
end
go

-----------------GetTypes------------

create procedure [46008527].GetTypes
as
begin
select * from [46008527].CarType
end
go

------------------Get Transmission Type---------------

create procedure [46008527].GetTransmission
as
begin
select * from [46008527].CarTransmissionType
end
go